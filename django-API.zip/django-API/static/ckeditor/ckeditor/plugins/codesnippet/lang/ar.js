﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","ar",{button:"أدمج قصاصة الشيفرة",codeContents:"محتوى الشيفرة",emptySnippetError:"قصاصة الشيفرة لايمكن أن تكون فارغة.",language:"لغة",title:"قصاصة الشيفرة",pathName:"قصاصة الشيفرة"});