from django.contrib.auth.models import User
from rest_framework import serializers

from blogs.models import Post, Category, Comment, Tag


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        fields = (
            "id",
            "name",
        )
        model = Category


class TagSerializer(serializers.ModelSerializer):
    class Meta:
        fields = (
            "id",
            "name",
        )
        model = Tag


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        fields = (
            "id",
            "username",
        )
        model = User


class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        fields = '__all__'
        model = Comment


class PostSerializer(serializers.ModelSerializer):
    category = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all())
    comments = serializers.SerializerMethodField()
    author = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())
    tags = serializers.PrimaryKeyRelatedField(many=True, queryset=Tag.objects.all())

    class Meta:
        fields = (
            "id",
            "name",
            "description",
            "slug",
            "author",
            "tags",
            "category",
            "comments",
        )
        model = Post

    def to_internal_value(self, data):
        if 'category' in data and isinstance(data['category'], int):
            category_id = data.pop('category')
            data['category'] = category_id

        if 'author' in data and isinstance(data['author'], int):
            author_id = data.pop('author')
            data['author'] = author_id

        if 'tags' in data and all(isinstance(tag, int) for tag in data['tags']):
            tag_ids = data.pop('tags')
            data['tags'] = tag_ids

        return super().to_internal_value(data)

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        request = self.context.get('request')
        if request and request.method == 'GET':
            category = instance.category
            ret['category'] = CategorySerializer(category).data

            author = instance.author
            ret['author'] = UserSerializer(author).data

            tags = instance.tags.all()
            ret['tags'] = TagSerializer(tags, many=True).data
        return ret

    def get_comments(self, instance):
        include_comments = self.context['request'].query_params.get('include') == 'comments'
        if include_comments:
            return CommentSerializer(instance.comments.all(), many=True).data
        else:
            return None